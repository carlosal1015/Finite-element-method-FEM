Polynomial::Polynomial (int n) 
  : SimpleFloatArray(n+1,0.0) {}
