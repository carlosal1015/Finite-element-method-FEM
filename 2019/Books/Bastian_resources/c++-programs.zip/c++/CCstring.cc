#include "fcpp.hh"
#include <string>

int main ()
{
  std::string vorname = "Peter";
  std::string nachname = "Bastian";
  std::string name = vorname + " " + nachname;
  print(name);
}
  
