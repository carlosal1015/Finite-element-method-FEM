  int quadrat (int x)
  {
      return x*x;
  }
  
