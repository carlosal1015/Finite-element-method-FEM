#include "fcpp.hh"

int main ()
{
  return print( (3+(5*8))-(16*(7+9)) );
}
  
