float& SimpleFloatArray::operator[] (int i)
{
  return p[i];
}
