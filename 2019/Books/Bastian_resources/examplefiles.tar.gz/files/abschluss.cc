#include <iostream>

#include "cond.h"

int main()
{
  std::string eingabe;
  std::cout << "War diese Einführung hilfreich? ";
  std::cin >> eingabe;
  cond(eingabe == "ja",
       std::cout << "Sehr schön!" << std::endl,
       std::cout << "Schade!" << std::endl);
  return 0;
}
