#include <iostream>

int main()
{
  int x;
  std::cout << "Hello World!" << std::endl;
  return 0;
}
