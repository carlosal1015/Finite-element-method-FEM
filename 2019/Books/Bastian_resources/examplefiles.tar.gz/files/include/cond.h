#define cond(a,b,c) ( (a) ? (b) : (c) )

